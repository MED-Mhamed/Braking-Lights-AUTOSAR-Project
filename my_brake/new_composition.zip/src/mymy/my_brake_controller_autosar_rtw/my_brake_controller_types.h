/*
 * File: my_brake_controller_types.h
 *
 * Code generated for Simulink model 'my_brake_controller'.
 *
 * Model version                  : 10.3
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Mon Aug 12 17:49:28 2024
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef my_brake_controller_types_h_
#define my_brake_controller_types_h_
#endif                                 /* my_brake_controller_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
