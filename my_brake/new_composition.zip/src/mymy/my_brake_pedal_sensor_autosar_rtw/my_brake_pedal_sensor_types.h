/*
 * File: my_brake_pedal_sensor_types.h
 *
 * Code generated for Simulink model 'my_brake_pedal_sensor'.
 *
 * Model version                  : 9.3
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Mon Aug 12 17:49:41 2024
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef my_brake_pedal_sensor_types_h_
#define my_brake_pedal_sensor_types_h_
#include "Rte_Type.h"
#endif                                 /* my_brake_pedal_sensor_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
